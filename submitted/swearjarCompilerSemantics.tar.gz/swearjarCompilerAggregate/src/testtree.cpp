/*
 * Team Literally Cool
 *
 * testtree.cpp
 *
 * This is the implementation of the generic extender of the generic tree, for testing purposes.
 */

#include "testtree.h"

