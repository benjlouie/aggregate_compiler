/*
 * Team Literally Cool
 *
 * testtree.h
 *
 * This is the header file for the generic extender of the generic tree, for testing purposes.
 */

#ifndef __TESTTREE_H_
#define __TESTTREE_H_
#include "tree.h"

class TestTree : public Tree
{
};

#endif /* __TESTTREE_H_ */
